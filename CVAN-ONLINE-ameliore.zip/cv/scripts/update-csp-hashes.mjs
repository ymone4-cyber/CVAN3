// Recalcule les empreintes SHA-256 des scripts inline et met à jour la CSP de index.html.
// À lancer après TOUTE modification d'un <script> inline, sinon le navigateur le bloque : npm run csp
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
const files = process.argv.slice(2).length ? process.argv.slice(2) : ["index.html"];
for (const file of files) {
  let html = readFileSync(file, "utf8");
  const hashes = [...html.matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g)]
    .map((m) => `'sha256-${createHash("sha256").update(m[1], "utf8").digest("base64")}'`);
  const re = /(<meta http-equiv="Content-Security-Policy" content=")([^"]*)(")/;
  const m = html.match(re);
  if (!m) throw new Error(`CSP introuvable dans ${file}`);
  const directives = m[2].split(";").map((d) => d.trim()).filter(Boolean).map((d) => {
    if (!d.startsWith("script-src ")) return d;
    const kept = d.split(/\s+/).filter((t) => !t.startsWith("'sha256-"));
    return [...kept, ...hashes].join(" ");
  });
  html = html.replace(re, `$1${directives.join("; ")}$3`);
  writeFileSync(file, html);
  console.log(`${file} : ${hashes.length} empreinte(s) à jour`);
}
