// Netlify publie le dossier public/. Les fichiers à la racine servent à l'import Lovable.
// Ce script copie la racine vers public/ pour qu'ils ne divergent jamais : npm run sync
import { copyFileSync } from "node:fs";
for (const f of ["index.html", "cvan-mars.js"]) { copyFileSync(f, `public/${f}`); console.log(`${f} -> public/${f}`); }
