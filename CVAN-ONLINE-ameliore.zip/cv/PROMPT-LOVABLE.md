# Migration CVAN.ONLINE vers Lovable — accueil 3D en trois scènes

Migre le code importé vers une application Lovable maintenable, en français. Le brief « Redline — Mars Trips » sert de référence visuelle et de mouvement pour l’accueil. Garde le nom, l’identité, les parcours et les règles métier de CVAN.ONLINE.

## Accueil CVAN inspiré du brief Mars

- Utilise public/index.html et public/cvan-mars.js comme référence de l’accueil en trois scènes.
- Garde la navigation CVAN, les boutons Évaluation, Espace enseignant, Contact et Commencer, ainsi que les formulaires et écrans existants.
- Reprends l’atmosphère terracotta et orange, le grand titre, le globe Mars en Three.js r170, les poussières lumineuses et la transition continue en trois étapes.
- Étape 1 : faire apparaître le globe derrière le nom CVAN.
- Étape 2 : déplacer et faire tourner le globe, puis présenter les quatre éléments réels du site : logique déductive, raisonnement quantitatif, psychologie appliquée et attestation. Le survol et le clavier permettent de choisir un domaine.
- Étape 3 : faire évoluer la scène vers le canyon, puis afficher une barre claire avec les données réelles du parcours et le bouton qui ouvre l’évaluation.
- Conserve les images de référence déjà incluses dans cvan-mars.js si elles sont accessibles. L’accueil reste utilisable lorsque WebGL ou ces images ne chargent pas.
- La molette, le clavier, les indicateurs d’étape et les boutons doivent permettre de parcourir les scènes. Depuis la troisième scène, le défilement rejoint le contenu d’évaluation. Les interactions restent accessibles sur téléphone et au clavier, avec prise en charge du mouvement réduit.
- Garde les textes en français et les informations exactes : 3 étapes, 6 questions par étape et 4 bonnes réponses sur 6 pour valider. Ne crée pas de contenu de voyage, d’achat de billet ou d’autres marques.
- N’invente pas de témoignages. L’illustration Mars est un décor de présentation pédagogique.

## Fonctions de CVAN à préserver

- Préserve le parcours étudiant et ses questions, le chronomètre, les résultats, l’attestation et l’envoi de courriel.
- Préserve les évaluations PDF créées par l’enseignant : PDF des questions et corrigé privé, analyse des questions, activation/désactivation, soumissions et consultation des copies.
- Garde les QCM corrigés automatiquement. Les réponses rédigées proches du corrigé suivent le seuil actuel; les cas incertains restent proposés à une vérification manuelle.
- Garde les quatre styles d’icône œil Goku, Naruto, Minato et Kyûbi avec des motifs SVG originaux et sans images ou logos officiels.
- Les contrôles de navigation existants continuent d’ouvrir le bon espace. Ne désactive pas les parcours de contact.

## Hébergement Lovable et protection de l’espace enseignant

- Remplace les fonctions Netlify et Netlify Blobs par Lovable Cloud : base de données, authentification, stockage privé et fonctions serveur. Le site publié ne doit plus dépendre des fonctions Netlify.
- Configure un seul compte propriétaire et désactive toute inscription publique d’enseignant. Demande l’adresse courriel propriétaire dans l’interface Lovable. Ne me demande pas de mot de passe dans la discussion et n’enregistre aucun mot de passe dans le code ou le navigateur.
- Protège chaque action et donnée privée côté serveur avec les rôles, les règles RLS et les politiques de stockage. Un bouton masqué ou une vérification JavaScript ne constitue pas une protection.
- Les visiteurs anonymes peuvent consulter uniquement les questions de l’évaluation active et envoyer leur copie. Ils ne peuvent pas lire le corrigé, les réponses attendues, les évaluations inactives ou les copies d’autres étudiants.
- Le propriétaire est le seul à pouvoir lire ou modifier les PDF de corrigé, résultats, copies et réglages privés.
- Valide les soumissions et limites d’usage côté serveur. Le PDF des questions n’est public que pour l’évaluation active.
- Adapte la politique CSP au nouveau build : conserve les ressources nécessaires et évite l’autorisation générale de scripts en ligne.

## Données existantes

Le ZIP transporte le code source, pas les enregistrements ni les PDF conservés dans Netlify Blobs. Indique clairement qu’ils restent à exporter ou à réimporter. Ne prétends pas qu’ils ont été transférés.

## Livraison

Reconstruis l’application Lovable à partir des fonctions et contenus importés. Active Lovable Cloud lorsqu’il est requis, construis un aperçu et vérifie visuellement les trois scènes, la navigation, le parcours étudiant et le parcours propriétaire ainsi que les règles RLS et de stockage. Résume les changements et demande seulement les informations manquantes nécessaires, en particulier l’adresse courriel du compte propriétaire.
