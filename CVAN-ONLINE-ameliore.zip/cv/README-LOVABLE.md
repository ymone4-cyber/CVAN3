# Importer CVAN.ONLINE dans Lovable

Cette archive contient le site CVAN actuel et un nouvel accueil inspiré du brief « Redline — Mars Trips » : globe 3D, ambiance terracotta et navigation en trois scènes. Les contenus et les boutons restent ceux de CVAN.

## Étapes

1. Dans Lovable, crée un projet avec **Import project to Lovable**.
2. Choisis **Upload code**, puis sélectionne **CVAN-ONLINE-Lovable-Mars.zip**.
3. Une fois le projet importé, colle le contenu de **PROMPT-LOVABLE.md** dans la discussion du projet.
4. Si Lovable te demande de choisir entre la migration et l’accueil 3D, choisis la migration : l’accueil à trois scènes est déjà inclus et le prompt demande de le préserver.
5. Suis les demandes de Lovable pour activer Lovable Cloud et indiquer le courriel du compte propriétaire. Ne colle aucun mot de passe ou secret dans le chat.
6. Avant de publier, demande l’aperçu des trois scènes, des boutons d’évaluation et de contact, du parcours étudiant et de l’espace propriétaire.

La documentation Lovable explique l’import de code depuis un ZIP : [Importer un projet dans Lovable](https://docs.lovable.dev/features/projects/import-project).

## Données à conserver

L’archive transporte les fichiers du site, pas les évaluations, les copies étudiantes ni les PDF conservés chez Netlify. Ces données devront être exportées puis réimportées. Le prompt demande à Lovable de remplacer les fonctions Netlify par Lovable Cloud et de réserver toutes les données privées au compte propriétaire.

Le globe et les photos sont chargés depuis les adresses intégrées au fichier source. Le site affiche un globe de secours si WebGL n’est pas disponible.
