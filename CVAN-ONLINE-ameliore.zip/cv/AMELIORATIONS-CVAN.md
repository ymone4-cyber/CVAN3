# CVAN.ONLINE — audit, corrections et améliorations (10 novembre 2026)

## Audit
Le projet était sain : les 5 scripts et le module 3D ont une syntaxe valide, aucune variable inexistante, toutes les empreintes de la politique de sécurité (CSP) étaient correctes, les fonctions serveur sont bien conçues (session signée, comparaison à temps constant, même origine, limitation de débit, validation des identifiants, copies chiffrées). Le site se charge sans erreur JavaScript.

## Défaut fonctionnel corrigé
Les banques de questions « jamais deux fois la même » étaient trop petites : 18 à 30 questions par étape pour 6 posées. Un étudiant qui échouait quelques fois était **bloqué définitivement** (« Banque de questions épuisée »). Les banques logiques passent à **66 questions** (11 tentatives complètes au lieu de 5).
**Reste à faire (contenu)** : la banque de psychologie (étape 3) n'a que 18 questions = 3 tentatives. Il faut ajouter des questions dans `EXTRA_PSY`, ou décider d'autoriser des répétitions après épuisement.

## Sécurité
- EmailJS épinglé en `4.4.1` avec contrôle d'intégrité SRI (avant : `@4` flottant, sans contrôle).
- `submit-attempt` : une copie déjà enregistrée n'est plus jamais écrasée ; un renvoi réussit sans doublon.
- `netlify.toml` : en-têtes `X-Content-Type-Options`, `X-Frame-Options`, `Strict-Transport-Security`, `Referrer-Policy`, `Cross-Origin-Opener-Policy`, `frame-ancestors 'none'`.

## Maintenance
- `npm run csp` : recalcule les empreintes CSP des scripts inline. **À lancer après toute modification d'un `<script>` inline**, sinon le navigateur le bloque.
- `npm run sync` : copie `index.html` et `cvan-mars.js` de la racine vers `public/` (Netlify publie `public/`). `npm run build:site` fait les deux.
- `npm test` (après `npm i -D jsdom`) : vérifie les empreintes CSP, l'identité racine/public, le chargement sans erreur, la validité de 15 banques et l'exactitude des suites L1 à L3.
- Balises Open Graph ajoutées (aperçu de partage).

## Déploiement
Rien à changer : poussez le dossier comme avant. La variable `CVAN_TEACHER_PASSWORD` reste obligatoire sur Netlify.

## Non vérifié ici
Fonctions Netlify avec le vrai stockage Blobs, envoi réel des e-mails EmailJS, rendu du globe WebGL, affichage sur téléphone, chargement des images externes, attestation imprimée.
