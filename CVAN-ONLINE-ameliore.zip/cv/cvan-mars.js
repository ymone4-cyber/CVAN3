(() => {
  "use strict";
  const hero=document.getElementById("hero"),landing=document.getElementById("cvan-landing");
  if(!hero||!landing)return;
  const reduceMotion=window.matchMedia("(prefers-reduced-motion: reduce)");
  const assets={
    map:"https://images.higgs.ai/?default=1&output=webp&url=https%3A%2F%2Fd8j0ntlcm91z4.cloudfront.net%2Fuser_38xzZboKViGWJOttwIXH07lWA1P%2Fhf_20261031_030432_a1948696-c1d5-4468-845e-7d1291f80943.png&w=2688&q=92",
    land:"https://images.higgs.ai/?default=1&output=webp&url=https%3A%2F%2Fd8j0ntlcm91z4.cloudfront.net%2Fuser_38xzZboKViGWJOttwIXH07lWA1P%2Fhf_20261031_030420_da39d0cf-af67-4e33-a487-6469549cfbff.png&w=2400&q=88",
    fore:"https://images.higgs.ai/?default=1&output=webp&url=https%3A%2F%2Fd8j0ntlcm91z4.cloudfront.net%2Fuser_38xzZboKViGWJOttwIXH07lWA1P%2Fhf_20261031_030420_fe406b69-3e6f-4b7c-a17e-ef09db0d270b.png&w=2400&q=88",
    cards:"https://images.higgs.ai/?default=1&output=webp&url=https%3A%2F%2Fd8j0ntlcm91z4.cloudfront.net%2Fuser_38xzZboKViGWJOttwIXH07lWA1P%2Fhf_20261031_030420_e222aa05-c121-4f31-a466-0321badc0e28.png&w=1400&q=85"
  };
  const sites=[
    {name:"Logique déductive",short:"Observer · relier · conclure",u:.121,v:.31,box:[0,0,1150,810]},
    {name:"Raisonnement quantitatif",short:"Nombres · proportions · méthode",u:.45,v:.56,box:[1186,0,1150,810]},
    {name:"Psychologie appliquée",short:"Situations · écoute · décision",u:.85,v:.75,box:[0,900,1150,810]},
    {name:"Attestation",short:"Progression · validation · résultat",u:.61,v:.35,box:[1186,900,1150,810]}
  ];
  const $=id=>document.getElementById(id);
  const word0=$("word0"),eyebrow=$("eyebrow"),gl=$("gl"),dust=$("dust"),flare=$("flare"),pin=$("pin"),word1=$("word1"),list=$("sites"),card=$("card"),region=$("region"),land=$("land"),dest=$("dest"),fore=$("fore"),fog=$("fog"),scrim=$("scrim"),bar=$("bar"),hint=$("hint"),stepNext=$("step-next"),fallback=$("globe-fallback");
  land.style.backgroundImage='url("'+assets.land+'")';fore.style.backgroundImage='url("'+assets.fore+'")';card.style.backgroundImage='url("'+assets.cards+'")';
  let selected=0;
  sites.forEach((site,index)=>{
    const li=document.createElement("li"),button=document.createElement("button");
    button.type="button";button.dataset.i=String(index);button.textContent=site.name;button.setAttribute("aria-label",site.name+" — "+site.short);
    li.appendChild(button);list.appendChild(li);
    button.addEventListener("mouseenter",()=>pick(index));button.addEventListener("focus",()=>pick(index));button.addEventListener("click",()=>{pick(index);go(2)});
  });
  function pick(index){
    selected=Math.max(0,Math.min(sites.length-1,index));
    list.querySelectorAll("li").forEach((li,i)=>{li.classList.toggle("on",i===selected);const b=li.querySelector("button");if(b)b.setAttribute("aria-pressed",i===selected?"true":"false")});
    $("region").textContent=sites[selected].name.toLocaleUpperCase("fr-FR");
    const box=sites[selected].box,x=box[0],y=box[1],w=box[2],h=box[3];
    card.style.backgroundSize=(2336/w*100)+"% "+(1744/h*100)+"%";card.style.backgroundPosition=(x/(2336-w)*100)+"% "+(y/(1744-h)*100)+"%";
    const active=list.querySelector("li.on");if(active){const r=active.getBoundingClientRect(),hr=hero.getBoundingClientRect();card.style.top=(r.top+r.height/2-card.offsetHeight/2-hr.top)+"px"}
  }
  pick(0);
  let st=0,from=0,to=0,t0=performance.now(),duration=1,mapReadyAt=performance.now(),lastDrag=0,yawVelocity=0,dragging=false,dragMoved=false,pointerX=0,pointerY=0,mouseX=0,mouseY=0,hasPointer=false;
  const mix=(a,b,k)=>a+(b-a)*k,clamp=x=>Math.max(0,Math.min(1,x)),seg=(p,a,b)=>clamp((p-a)/(b-a));
  const io=k=>k<.5?4*k*k*k:1-Math.pow(-2*k+2,3)/2,out=k=>1-Math.pow(1-k,3),rate=(dt,r)=>1-Math.exp(-dt*r);
  const wrapAngle=(a,b)=>{let d=(b-a+Math.PI)%(Math.PI*2);if(d<0)d+=Math.PI*2;return d-Math.PI};
  function fit(){const r=hero.getBoundingClientRect();return{W:Math.max(1,r.width),H:Math.max(1,r.height),left:r.left,top:r.top}}
  function go(next){
    next=Math.max(0,Math.min(2,next));if(next===to)return;
    const now=performance.now();from=st;to=next;t0=now;
    if(reduceMotion.matches){duration=1;return}
    if(next>st)duration=Math.max(0,Math.min(next,1)-st)*1300+Math.max(0,next-Math.max(st,1))*2500;
    else duration=Math.max(0,st-Math.max(next,1))*2500+Math.max(0,Math.min(st,1)-next)*1300;
  }
  document.querySelectorAll("#rail [data-step]").forEach(b=>b.addEventListener("click",()=>go(Number(b.dataset.step))));
  stepNext.addEventListener("click",()=>go(Math.min(2,to+1)));
  function openEvaluation(){if(typeof window.showSiteView==="function")window.showSiteView("evaluation");const app=$("app");if(app)window.setTimeout(()=>app.scrollIntoView({behavior:reduceMotion.matches?"auto":"smooth",block:"start"}),30)}
  $("explore").addEventListener("click",openEvaluation);$("explore-card").addEventListener("click",e=>{e.preventDefault();openEvaluation()});
  const home=$("home");if(home)home.addEventListener("click",e=>{e.preventDefault();go(0);window.scrollTo({top:0,behavior:reduceMotion.matches?"auto":"smooth"})});
  document.querySelectorAll("[data-cvan-scroll-app]").forEach(b=>b.addEventListener("click",openEvaluation));
  const closeAnnouncement=$("close-announcement");if(closeAnnouncement)closeAnnouncement.addEventListener("click",()=>document.body.classList.add("topbar-dismissed"));
  hero.addEventListener("wheel",e=>{if(Math.abs(e.deltaY)<8)return;if(e.deltaY<0&&to===0)return;if(e.deltaY>0&&to===2)return;e.preventDefault();go(to+(e.deltaY>0?1:-1))},{passive:false});
  window.addEventListener("keydown",e=>{
    if(e.key==="Escape"&&to>0){go(to-1);return}
    if(e.target&&e.target.closest&&e.target.closest("input,textarea,select,button,a,[contenteditable=true]"))return;
    const visible=hero.getBoundingClientRect().bottom>0&&hero.getBoundingClientRect().top<innerHeight;
    if((e.key==="ArrowDown"||e.key==="PageDown")&&visible&&to<2){e.preventDefault();go(to+1)}
    if((e.key==="ArrowUp"||e.key==="PageUp")&&visible&&to>0){e.preventDefault();go(to-1)}
  });
  let dragPointer=-1,lastX=0,lastY=0,dragYaw=0,dragPitch=.16;
  let renderer=null,scene=null,camera=null,planet=null,tilt=null,spin=null,material=null,THREE=null,planetX=0,planetY=0,planetRadius=1,baseRadius=1,glW=0,glH=0,lastYaw=0,lastPitch=.16,lastFrame=performance.now();
  hero.addEventListener("pointermove",e=>{const r=fit();pointerX=e.clientX-r.left;pointerY=e.clientY-r.top;mouseX=pointerX/r.W-.5;mouseY=pointerY/r.H-.5;hasPointer=true;if(dragging&&e.pointerId===dragPointer){const dx=e.clientX-lastX,dy=e.clientY-lastY,k=1.1/Math.max(80,baseRadius);dragYaw+=dx*k;dragPitch=Math.max(-1,Math.min(1,dragPitch+dy*k));yawVelocity=dx*k;lastX=e.clientX;lastY=e.clientY;dragMoved=dragMoved||Math.abs(dx)+Math.abs(dy)>2;lastDrag=performance.now()}},{passive:true});
  gl.addEventListener("pointerdown",e=>{if(st>1.02)return;const r=gl.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;if(Math.hypot(x-planetX,y-planetY)>planetRadius)return;dragging=true;dragMoved=false;dragPointer=e.pointerId;lastX=e.clientX;lastY=e.clientY;dragYaw=lastYaw;dragPitch=lastPitch;gl.classList.add("drag");try{gl.setPointerCapture(e.pointerId)}catch{}});
  gl.addEventListener("pointerup",e=>{if(!dragging||e.pointerId!==dragPointer)return;dragging=false;gl.classList.remove("drag");try{gl.releasePointerCapture(e.pointerId)}catch{}if(!dragMoved&&to<2)go(to+1);lastDrag=performance.now()});
  gl.addEventListener("pointercancel",()=>{dragging=false;gl.classList.remove("drag")});
  const dustCtx=dust.getContext("2d");let dustW=0,dustH=0,dustScale=1,motes=[];
  function drawDust(now,landingStage){const t=now*.001;dustCtx.setTransform(dustScale,0,0,dustScale,0,0);dustCtx.clearRect(0,0,dustW,dustH);for(const m of motes){const x=((m.x+t*m.s+2)%1.1-.05)*dustW,y=(m.y+Math.sin(t*.3+m.p)*.02)*dustH,alpha=(.3+.35*Math.sin(t*.7+m.p)**2)*(landingStage?.7:1),g=dustCtx.createRadialGradient(x,y,0,x,y,m.r);g.addColorStop(0,"rgba(255,214,170,"+(.95*alpha)+")");g.addColorStop(.4,"rgba(255,180,120,"+(.42*alpha)+")");g.addColorStop(1,"rgba(255,180,120,0)");dustCtx.fillStyle=g;dustCtx.fillRect(x-m.r,y-m.r,m.r*2,m.r*2)}}
  function resizeDust(){const r=fit();dustScale=Math.min(devicePixelRatio||1,1.5);dust.width=Math.round(r.W*dustScale);dust.height=Math.round(r.H*dustScale);dust.style.width=r.W+"px";dust.style.height=r.H+"px";dustW=r.W;dustH=r.H;motes=Array.from({length:34},(_,i)=>{const f=x=>{const n=Math.sin((i+1)*x+16.71)*43758.5453;return n-Math.floor(n)};return{x:f(12.1),y:f(23.4),r:3+f(3.8)**2*34,s:.004+f(8.1)*.012,p:f(9.4)*6.28}})}
  function fallbackTexture(T){const c=document.createElement("canvas");c.width=1344;c.height=672;const ctx=c.getContext("2d"),g=ctx.createLinearGradient(0,0,c.width,c.height);g.addColorStop(0,"#d98a52");g.addColorStop(.4,"#a74b24");g.addColorStop(1,"#54200f");ctx.fillStyle=g;ctx.fillRect(0,0,c.width,c.height);let seed=713;const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296};for(let i=0;i<180;i++){const x=rnd()*c.width,y=rnd()*c.height,r=5+rnd()*45;ctx.beginPath();ctx.ellipse(x,y,r,r*(.25+rnd()*.55),rnd()*Math.PI,0,Math.PI*2);ctx.fillStyle=i%3===0?"rgba(247,176,113,.14)":"rgba(39,10,4,.13)";ctx.fill()}const tex=new T.CanvasTexture(c);tex.colorSpace=T.NoColorSpace;tex.wrapS=T.RepeatWrapping;tex.anisotropy=renderer.capabilities.getMaxAnisotropy();return tex}
  function makeMap(image,T){const W=2688,H=1344,c=document.createElement("canvas");c.width=W;c.height=H;const ctx=c.getContext("2d");ctx.drawImage(image,0,0,W,H);const fw=Math.round(W*.07),temp=document.createElement("canvas");temp.width=fw;temp.height=H;const tc=temp.getContext("2d");tc.drawImage(c,0,0,fw,H,0,0,fw,H);tc.globalCompositeOperation="destination-in";let fade=tc.createLinearGradient(0,0,fw,0);fade.addColorStop(0,"rgba(255,255,255,0)");fade.addColorStop(1,"rgba(255,255,255,1)");tc.fillStyle=fade;tc.fillRect(0,0,fw,H);ctx.drawImage(temp,W-fw,0);fade=ctx.createLinearGradient(0,0,0,H*.035);fade.addColorStop(0,"#e9dfd2");fade.addColorStop(1,"rgba(233,223,210,0)");ctx.fillStyle=fade;ctx.fillRect(0,0,W,H*.035);fade=ctx.createLinearGradient(0,H*.965,0,H);fade.addColorStop(0,"rgba(233,223,210,0)");fade.addColorStop(1,"#e9dfd2");ctx.fillStyle=fade;ctx.fillRect(0,H*.965,W,H*.035);const tex=new T.CanvasTexture(c);tex.colorSpace=T.NoColorSpace;tex.wrapS=T.RepeatWrapping;tex.anisotropy=renderer.capabilities.getMaxAnisotropy();tex.needsUpdate=true;return tex}
  function createScene(T){
    THREE=T;scene=new T.Scene();camera=new T.OrthographicCamera(-1,1,1,-1,-200000,200000);camera.position.z=1000;
    renderer=new T.WebGLRenderer({canvas:gl,alpha:true,antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));renderer.setClearColor(0,0);renderer.outputColorSpace=T.SRGBColorSpace;
    planet=new T.Group();scene.add(planet);tilt=new T.Group();planet.add(tilt);spin=new T.Group();tilt.add(spin);
    material=new T.ShaderMaterial({transparent:true,uniforms:{map:{value:fallbackTexture(T)},ready:{value:1},texel:{value:new T.Vector2(1/2688,1/1344)},sun:{value:new T.Vector3(.62,.5,.6).normalize()},hiDir:{value:new T.Vector3(0,0,1)},hi:{value:0},hiR:{value:.62}},
      vertexShader:"varying vec2 vUv;varying vec3 vObj;varying vec3 vN;void main(){vUv=uv;vObj=normalize(position);vN=normalize(mat3(modelMatrix)*normal);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",
      fragmentShader:"uniform sampler2D map;uniform vec2 texel;uniform vec3 sun,hiDir;uniform float hi,hiR,ready;varying vec2 vUv;varying vec3 vObj;varying vec3 vN;float luma(vec2 u){return dot(texture2D(map,u).rgb,vec3(.3,.6,.1));}void main(){vec3 col=texture2D(map,vUv).rgb;col=pow(col,vec3(2.6))*vec3(1.18,.74,.56);vec3 n=normalize(vN);vec3 t=normalize(cross(vec3(0.,1.,0.),n)),b=cross(n,t);float dx=luma(vUv+vec2(texel.x*2.,0.))-luma(vUv-vec2(texel.x*2.,0.));float dy=luma(vUv+vec2(0.,texel.y*2.))-luma(vUv-vec2(0.,texel.y*2.));n=normalize(n-(t*dx+b*dy)*1.9);float diff=max(dot(n,sun),0.);vec3 lit=col*(vec3(1.5,1.32,1.18)*pow(diff,.85)+vec3(.2,.09,.06));float d=acos(clamp(dot(normalize(vObj),hiDir),-1.,1.))+(luma(vUv)-.45)*.22;float m=smoothstep(hiR,hiR-.03,d),edge=smoothstep(.03,0.,abs(d-hiR+.01));lit=mix(lit,mix(lit,vec3(.62,.012,.07)*(.25+diff*1.05)*(.5+luma(vUv)*1.1),.9),m*hi)+vec3(1.,.42,.4)*edge*hi*.22;float fres=pow(1.-max(vN.z,0.),3.2);lit+=vec3(1.,.5,.26)*fres*(.05+diff*.5);lit=lit/(lit*.3+1.)*1.3;gl_FragColor=vec4(pow(lit,vec3(1./2.2)),1.)*ready;}"
    });
    const sphere=new T.Mesh(new T.SphereGeometry(1,128,96),material);spin.add(sphere);
    const atmoMat=new T.ShaderMaterial({side:T.BackSide,blending:T.AdditiveBlending,transparent:true,depthWrite:false,uniforms:{sun:{value:new T.Vector3(.62,.5,.6).normalize()},ready:{value:1}},vertexShader:"varying vec3 vN;void main(){vN=normalize(mat3(modelMatrix)*normal);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",fragmentShader:"uniform vec3 sun;uniform float ready;varying vec3 vN;void main(){float z=clamp(-vN.z,0.,1.),a=smoothstep(.0,.55,z);float s=.55+.6*max(dot(-vN*vec3(1.,1.,0.),normalize(sun*vec3(1.,1.,0.))),0.);a=pow(a,2.6)*s*.7;gl_FragColor=vec4(vec3(1.,.64,.36),a*ready);}"});
    planet.add(new T.Mesh(new T.SphereGeometry(1.14,64,48),atmoMat));
    const loader=new T.TextureLoader();loader.setCrossOrigin("anonymous");
    loader.load(assets.map,image=>{try{material.uniforms.map.value=makeMap(image,T);material.needsUpdate=true;mapReadyAt=performance.now()}catch{mapReadyAt=performance.now()}},undefined,()=>{mapReadyAt=performance.now()});
    resizeScene();
  }
  function resizeScene(){if(!renderer||!camera)return;const r=fit();renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));renderer.setSize(r.W,r.H,false);camera.left=-r.W/2;camera.right=r.W/2;camera.top=r.H/2;camera.bottom=-r.H/2;camera.updateProjectionMatrix();glW=r.W;glH=r.H}
  function pointDir(u,v){const ph=2*Math.PI*u,th=Math.PI*v;return new THREE.Vector3(-Math.cos(ph)*Math.sin(th),Math.cos(th),Math.sin(ph)*Math.sin(th))}
  function render(now){
    requestAnimationFrame(render);if(document.hidden||landing.hidden||!renderer)return;
    const r=fit(),W=r.W,H=r.H;if(Math.abs(W-glW)>1||Math.abs(H-glH)>1)resizeScene();
    const dt=Math.min(.05,Math.max(.001,(now-lastFrame)/1000));lastFrame=now;
    const age=(now-mapReadyAt)/1000,grow=out(seg(age,0,1.5)),iw=out(seg(age,.75,1.7));
    st=mix(from,to,io(seg(now,t0,t0+duration)));if(Math.abs(st-to)<.0005)st=to;
    const a=clamp(st),b=clamp(st-1),bz=io(seg(b,0,.62)),portrait=H>W*1.05,R0=portrait?W*.36:Math.min(H*.3,W*.19);baseRadius=R0;
    const px=portrait?.5*W:mix(.5*W,.36*W,a),py=portrait?mix(.4*H,.33*H,a):.5*H;
    planetRadius=R0*mix(.03,1,grow)*(1+a*.04)*Math.exp(bz*2.5);planetX=mix(px,.5*W,bz);planetY=mix(py,.5*H,bz);planet.position.set(planetX-W/2,H/2-planetY,0);planet.scale.setScalar(planetRadius);
    const homeDir=pointDir(.4,.5),homeYaw=Math.atan2(-homeDir.x,homeDir.z);let yaw=homeYaw,pitch=.16;
    if(dragging){yaw=dragYaw;pitch=dragPitch}
    else if(st<.02&&now-lastDrag>1500&&!reduceMotion.matches){yaw=homeYaw+(now-mapReadyAt)*.001*(.08+(1-grow)*2.4)}
    else if(st>.02){const target=pointDir(b>.02?sites[selected].u:.15,b>.02?sites[selected].v:.41),targetYaw=Math.atan2(-target.x,target.z),targetPitch=Math.asin(target.y);yaw=lastYaw+wrapAngle(lastYaw,targetYaw)*rate(dt,3.6);pitch=mix(lastPitch,targetPitch,rate(dt,3.6))}
    else{yaw=lastYaw+wrapAngle(lastYaw,homeYaw)*rate(dt,1.4);pitch=mix(lastPitch,.16,rate(dt,1.2))}
    if(!dragging&&Math.abs(yawVelocity)>.00001){yaw+=yawVelocity;yawVelocity*=Math.exp(-dt*4)}
    lastYaw=yaw;lastPitch=pitch;spin.rotation.y=yaw;tilt.rotation.x=pitch;
    const hiDir=pointDir(b>.02?sites[selected].u:.15,b>.02?sites[selected].v:.41);material.uniforms.hiDir.value.copy(hiDir);material.uniforms.hiR.value=b>.02?mix(.62,.3,seg(b,0,.1)):.62;material.uniforms.hi.value=clamp(seg(a,.15,.6)+(b>0?1:0));
    const wh=word0.offsetHeight,ww=word0.offsetWidth,wordX=portrait?0:-a*.08*W,wordY=hasPointer?mouseY*-6:0,wordExtraY=portrait?H*-.1+planetRadius*1.08+wh*.5:0;
    word0.style.transform="translate(-50%,-50%) translate("+wordX+"px,"+(wordY+wordExtraY)+"px)";const inset=(1-iw)*50;word0.style.clipPath="inset(-10% "+inset+"% -10% "+inset+"%)";word0.style.opacity=String(1-seg(a,.1,.5));
    eyebrow.style.left=portrait?"50%":"calc(50% + "+(wordX+ww*.02)+"px)";eyebrow.style.top=portrait?(H*.5+wordExtraY+wh*.54+15)+"px":"calc(50% - "+(wh*.5+34)+"px)";eyebrow.style.transform="translateX(-50%)";eyebrow.style.opacity=String(iw*(1-seg(a,.05,.35)));
    flare.style.left=(planetX+planetRadius*.74)+"px";flare.style.top=(planetY-planetRadius*.62)+"px";flare.style.opacity=String(grow*(.88+.12*Math.sin(now*.001*1.3))*(1-seg(bz,0,.35)));hint.style.opacity=String(iw*.8*(1-seg(a,0,.25)));
    const pd=pointDir(.15,.41).applyAxisAngle(new THREE.Vector3(0,1,0),yaw).applyAxisAngle(new THREE.Vector3(1,0,0),pitch);pin.style.left=(planetX+pd.x*planetRadius-6)+"px";pin.style.top=(planetY-pd.y*planetRadius-8)+"px";pin.style.opacity=String(seg(pd.z,.02,.3)*seg(age,1.6,2.1)*(1-seg(a,0,.3)));
    const ka=seg(a,.45,1);word1.style.opacity=String(ka*(1-seg(b,.02,.16)));word1.style.transform="translate(-50%,0) translate("+(portrait?0:.02*W+(1-out(ka))*40)+"px,"+(portrait?.46*H:.56*H)+"px)";
    const so=seg(a,.55,1)*(1-seg(b,0,.14));list.style.opacity=String(so);list.style.pointerEvents=so>.6?"auto":"none";card.style.opacity=String(so);card.style.pointerEvents=so>.6?"auto":"none";card.style.transform="translateX("+(1-out(seg(a,.6,1)))*26+"px)";
    region.style.opacity=String(seg(b,.14,.26)*(1-seg(b,.42,.52)));gl.style.pointerEvents=st<1.02?"auto":"none";
    const fi=seg(b,.36,.54),fo=seg(b,.62,.96);fog.style.opacity=String(fi*(1-fo));
    const lk=out(seg(b,.5,1)),fk=out(seg(b,.58,1)),dk=out(seg(b,.66,.98)),drift=1+.02*Math.sin(now*.001*.18),mx=hasPointer?mouseX:0,my=hasPointer?mouseY:0;
    land.style.opacity=String(seg(b,.5,.64));land.style.transform="translate("+(mx*-14)+"px,"+mix(.2*H,my*-8,lk)+"px) scale("+mix(1.3,1.05,lk)*drift+")";
    fore.style.opacity=String(seg(b,.58,.72));fore.style.transform="translate("+(mx*-46)+"px,"+mix(.42*H,0,fk)+"px) scale(1.06)";
    dest.style.opacity=String(seg(b,.72,.9));dest.style.transform="translate("+(mx*-26)+"px,"+mix(.62*H,.27*H,dk)+"px)";dest.querySelector("small").style.opacity=String(seg(b,.8,1)*.92);
    const bk=seg(b,.86,1);bar.style.opacity=String(bk);bar.style.pointerEvents=bk>.88?"auto":"none";bar.style.transform="translate(-50%,"+((1-out(bk))*34)+"px)";scrim.style.opacity=String(seg(b,.6,.9));
    const stage=Math.max(0,Math.min(2,Math.round(st)));document.querySelectorAll("#rail [data-step]").forEach((button,i)=>button.classList.toggle("on",i===stage));
    const labels=["Découvrir les domaines","Voir la prochaine étape","Commencer l’évaluation"];stepNext.querySelector("span:first-child").textContent=labels[stage];stepNext.setAttribute("aria-label",labels[stage]);stepNext.style.opacity=String(stage===2?0:1);stepNext.style.pointerEvents=stage===2?"none":"auto";
    drawDust(now,stage===2);renderer.render(scene,camera);
  }
  function resizeDust(){const r=fit();dustScale=Math.min(devicePixelRatio||1,1.5);dust.width=Math.round(r.W*dustScale);dust.height=Math.round(r.H*dustScale);dust.style.width=r.W+"px";dust.style.height=r.H+"px";dustW=r.W;dustH=r.H;motes=Array.from({length:34},(_,i)=>{const f=x=>{const n=Math.sin((i+1)*x+16.71)*43758.5453;return n-Math.floor(n)};return{x:f(12.1),y:f(23.4),r:3+f(3.8)**2*34,s:.004+f(8.1)*.012,p:f(9.4)*6.28}})}
  window.addEventListener("resize",()=>{resizeScene();resizeDust()},{passive:true});
  resizeDust();
  import("three").then(T=>{try{createScene(T);fallback.hidden=true;requestAnimationFrame(render)}catch{fallback.hidden=false}}).catch(()=>{fallback.hidden=false});
})();
