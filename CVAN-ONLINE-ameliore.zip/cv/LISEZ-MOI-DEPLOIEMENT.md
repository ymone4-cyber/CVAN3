NOTE POUR LOVABLE

Ce paquet est préparé pour l’import dans Lovable. Le fichier PROMPT-LOVABLE.md demande de remplacer Netlify par Lovable Cloud et de préserver l’accueil CVAN en trois scènes. Utilise ce fichier après l’import.
