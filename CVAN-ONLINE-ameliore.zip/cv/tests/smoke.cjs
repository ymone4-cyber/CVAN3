// Test de fumée CVAN : npm i -D jsdom && npm test   (aucun appel réseau réel)
const { JSDOM, VirtualConsole } = require("jsdom"), fs = require("fs"), path = require("path"), crypto = require("crypto");
const root = path.resolve(__dirname, ".."), file = path.join(root, "index.html"), errs = [], rep = [];
const ok = (n, v) => { rep.push((v ? "OK   " : "ÉCHEC") + " " + n); if (!v) process.exitCode = 1; };
const html = fs.readFileSync(file, "utf8");
const csp = html.match(/Content-Security-Policy" content="([^"]*)"/)[1];
ok("CSP : toutes les empreintes des scripts inline sont valides", [...html.matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g)].every((m) => csp.includes("'sha256-" + crypto.createHash("sha256").update(m[1]).digest("base64") + "'")));
ok("racine et public/ identiques", ["index.html", "cvan-mars.js"].every((f) => fs.readFileSync(path.join(root, f), "utf8") === fs.readFileSync(path.join(root, "public", f), "utf8")));
const vc = new VirtualConsole(); vc.on("jsdomError", (e) => errs.push(String(e.message || e).slice(0, 160)));
JSDOM.fromFile(file, { runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: vc, beforeParse(w) {
  w.matchMedia = () => ({ matches: false, addEventListener() {} }); w.HTMLCanvasElement.prototype.getContext = () => null; w.scrollTo = () => {};
  w.IntersectionObserver = class { observe() {} unobserve() {} disconnect() {} };
  w.fetch = async () => ({ ok: true, status: 200, json: async () => ({}), text: async () => "{}" }); w.emailjs = { init() {}, send: async () => ({}) };
  w.speechSynthesis = { cancel() {}, speak() {}, getVoices: () => [], addEventListener() {} }; w.SpeechSynthesisUtterance = function () {}; } }).then(async (d) => {
  const w = d.window; await new Promise((r) => setTimeout(r, 800));
  ok("chargement sans erreur JavaScript", errs.length === 0);
  const r = JSON.parse(w.eval(`JSON.stringify((function(){const o={N:N,rows:[],math:true};
    for(const lv of ['L1','L2','L3','M1','M2']){for(let st=0;st<3;st++){const b=questionBank(lv,st);o.rows.push({lv,st,n:b.length,bad:b.filter(q=>q.length!==5||new Set(q.slice(1)).size!==4).length})}
      if(['L1','L2','L3'].includes(lv)){for(const q of generatedQuestions(lv,0)){const s=q[0].split(':').pop().split(',').map(x=>parseFloat(x)).filter(x=>!isNaN(x)),a=parseFloat(q[1]);
        const ok=lv==='L1'?(a-s[3]===s[1]-s[0]):lv==='L2'?(a/s[3]===s[1]/s[0]):(a-s[3]===9+0*s[0]&&s[3]-s[2]===7);if(!ok)o.math=false}}}
    return o})())`));
  ok("15 banques de questions valides (4 options distinctes)", r.rows.every((x) => x.bad === 0));
  ok("banques logiques : au moins 10 tentatives complètes par étape", r.rows.filter((x) => x.st < 2).every((x) => Math.floor(x.n / r.N) >= 10));
  ok("suites L1/L2/L3 : réponse mathématiquement correcte", r.math);
  const psy = r.rows.filter((x) => x.st === 2).map((x) => Math.floor(x.n / r.N));
  rep.push("INFO banque psychologie : " + Math.min(...psy) + " tentatives complètes avant épuisement (à enrichir)");
  console.log(rep.join("\n")); console.log("erreurs JS :", errs.length ? errs : "aucune"); process.exit(process.exitCode || 0);
});
